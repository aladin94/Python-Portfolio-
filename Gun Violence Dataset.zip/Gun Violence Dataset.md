

```python
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

```


```python
import matplotlib.pyplot as plt
df = pd.read_csv('C:\\Users\\admir\\Desktop\\gun-violence-data_01-2013_03-2018.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>incident_id</th>
      <th>date</th>
      <th>state</th>
      <th>city_or_county</th>
      <th>address</th>
      <th>n_killed</th>
      <th>n_injured</th>
      <th>incident_url</th>
      <th>source_url</th>
      <th>incident_url_fields_missing</th>
      <th>...</th>
      <th>participant_age</th>
      <th>participant_age_group</th>
      <th>participant_gender</th>
      <th>participant_name</th>
      <th>participant_relationship</th>
      <th>participant_status</th>
      <th>participant_type</th>
      <th>sources</th>
      <th>state_house_district</th>
      <th>state_senate_district</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>461105</td>
      <td>2013-01-01</td>
      <td>Pennsylvania</td>
      <td>Mckeesport</td>
      <td>1506 Versailles Avenue and Coursin Street</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/461105</td>
      <td>http://www.post-gazette.com/local/south/2013/0...</td>
      <td>False</td>
      <td>...</td>
      <td>0::20</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||3::Male||4::Female</td>
      <td>0::Julian Sims</td>
      <td>NaN</td>
      <td>0::Arrested||1::Injured||2::Injured||3::Injure...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://pittsburgh.cbslocal.com/2013/01/01/4-pe...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>460726</td>
      <td>2013-01-01</td>
      <td>California</td>
      <td>Hawthorne</td>
      <td>13500 block of Cerise Avenue</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/460726</td>
      <td>http://www.dailybulletin.com/article/zz/201301...</td>
      <td>False</td>
      <td>...</td>
      <td>0::20</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male</td>
      <td>0::Bernard Gillis</td>
      <td>NaN</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://losangeles.cbslocal.com/2013/01/01/man-...</td>
      <td>62.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>478855</td>
      <td>2013-01-01</td>
      <td>Ohio</td>
      <td>Lorain</td>
      <td>1776 East 28th Street</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/478855</td>
      <td>http://chronicle.northcoastnow.com/2013/02/14/...</td>
      <td>False</td>
      <td>...</td>
      <td>0::25||1::31||2::33||3::34||4::33</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Damien Bell||1::Desmen Noble||2::Herman Sea...</td>
      <td>NaN</td>
      <td>0::Injured, Unharmed, Arrested||1::Unharmed, A...</td>
      <td>0::Subject-Suspect||1::Subject-Suspect||2::Vic...</td>
      <td>http://www.morningjournal.com/general-news/201...</td>
      <td>56.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>478925</td>
      <td>2013-01-05</td>
      <td>Colorado</td>
      <td>Aurora</td>
      <td>16000 block of East Ithaca Place</td>
      <td>4</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/478925</td>
      <td>http://www.dailydemocrat.com/20130106/aurora-s...</td>
      <td>False</td>
      <td>...</td>
      <td>0::29||1::33||2::56||3::33</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Female||1::Male||2::Male||3::Male</td>
      <td>0::Stacie Philbrook||1::Christopher Ratliffe||...</td>
      <td>NaN</td>
      <td>0::Killed||1::Killed||2::Killed||3::Killed</td>
      <td>0::Victim||1::Victim||2::Victim||3::Subject-Su...</td>
      <td>http://denver.cbslocal.com/2013/01/06/officer-...</td>
      <td>40.0</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>478959</td>
      <td>2013-01-07</td>
      <td>North Carolina</td>
      <td>Greensboro</td>
      <td>307 Mourning Dove Terrace</td>
      <td>2</td>
      <td>2</td>
      <td>http://www.gunviolencearchive.org/incident/478959</td>
      <td>http://www.journalnow.com/news/local/article_d...</td>
      <td>False</td>
      <td>...</td>
      <td>0::18||1::46||2::14||3::47</td>
      <td>0::Adult 18+||1::Adult 18+||2::Teen 12-17||3::...</td>
      <td>0::Female||1::Male||2::Male||3::Female</td>
      <td>0::Danielle Imani Jameison||1::Maurice Eugene ...</td>
      <td>3::Family</td>
      <td>0::Injured||1::Injured||2::Killed||3::Killed</td>
      <td>0::Victim||1::Victim||2::Victim||3::Subject-Su...</td>
      <td>http://myfox8.com/2013/01/08/update-mother-sho...</td>
      <td>62.0</td>
      <td>27.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 29 columns</p>
</div>




```python
df.info()
#Our dataset consists of 29 columns of up to 239677 rows of data. 
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 239677 entries, 0 to 239676
    Data columns (total 29 columns):
    incident_id                    239677 non-null int64
    date                           239677 non-null object
    state                          239677 non-null object
    city_or_county                 239677 non-null object
    address                        223180 non-null object
    n_killed                       239677 non-null int64
    n_injured                      239677 non-null int64
    incident_url                   239677 non-null object
    source_url                     239209 non-null object
    incident_url_fields_missing    239677 non-null bool
    congressional_district         227733 non-null float64
    gun_stolen                     140179 non-null object
    gun_type                       140226 non-null object
    incident_characteristics       239351 non-null object
    latitude                       231754 non-null float64
    location_description           42089 non-null object
    longitude                      231754 non-null float64
    n_guns_involved                140226 non-null float64
    notes                          158660 non-null object
    participant_age                147379 non-null object
    participant_age_group          197558 non-null object
    participant_gender             203315 non-null object
    participant_name               117424 non-null object
    participant_relationship       15774 non-null object
    participant_status             212051 non-null object
    participant_type               214814 non-null object
    sources                        239068 non-null object
    state_house_district           200905 non-null float64
    state_senate_district          207342 non-null float64
    dtypes: bool(1), float64(6), int64(3), object(19)
    memory usage: 51.4+ MB
    


```python
df['state'].min() #Most popular country for gun violence of 2018
```




    'Alabama'




```python
df['state'].max() #Least popular country for gun violence of 2018
```




    'Wyoming'




```python
df['date'].max() #Date with most reported acts of gun violence.
```




    '2018-03-31'




```python
plt.plot('n_guns_involved', 'n_injured', data=df)
```




    [<matplotlib.lines.Line2D at 0x1ee9e864e48>]




![png](output_7_1.png)



```python
df.drop(columns=['participant_name','participant_relationship','participant_status'], axis=1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>incident_id</th>
      <th>date</th>
      <th>state</th>
      <th>city_or_county</th>
      <th>address</th>
      <th>n_killed</th>
      <th>n_injured</th>
      <th>incident_url</th>
      <th>source_url</th>
      <th>incident_url_fields_missing</th>
      <th>...</th>
      <th>longitude</th>
      <th>n_guns_involved</th>
      <th>notes</th>
      <th>participant_age</th>
      <th>participant_age_group</th>
      <th>participant_gender</th>
      <th>participant_type</th>
      <th>sources</th>
      <th>state_house_district</th>
      <th>state_senate_district</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>461105</td>
      <td>2013-01-01</td>
      <td>Pennsylvania</td>
      <td>Mckeesport</td>
      <td>1506 Versailles Avenue and Coursin Street</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/461105</td>
      <td>http://www.post-gazette.com/local/south/2013/0...</td>
      <td>False</td>
      <td>...</td>
      <td>-79.8559</td>
      <td>NaN</td>
      <td>Julian Sims under investigation: Four Shot and...</td>
      <td>0::20</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||3::Male||4::Female</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://pittsburgh.cbslocal.com/2013/01/01/4-pe...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>460726</td>
      <td>2013-01-01</td>
      <td>California</td>
      <td>Hawthorne</td>
      <td>13500 block of Cerise Avenue</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/460726</td>
      <td>http://www.dailybulletin.com/article/zz/201301...</td>
      <td>False</td>
      <td>...</td>
      <td>-118.3330</td>
      <td>NaN</td>
      <td>Four Shot; One Killed; Unidentified shooter in...</td>
      <td>0::20</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://losangeles.cbslocal.com/2013/01/01/man-...</td>
      <td>62.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>478855</td>
      <td>2013-01-01</td>
      <td>Ohio</td>
      <td>Lorain</td>
      <td>1776 East 28th Street</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/478855</td>
      <td>http://chronicle.northcoastnow.com/2013/02/14/...</td>
      <td>False</td>
      <td>...</td>
      <td>-82.1377</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>0::25||1::31||2::33||3::34||4::33</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Subject-Suspect||1::Subject-Suspect||2::Vic...</td>
      <td>http://www.morningjournal.com/general-news/201...</td>
      <td>56.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>478925</td>
      <td>2013-01-05</td>
      <td>Colorado</td>
      <td>Aurora</td>
      <td>16000 block of East Ithaca Place</td>
      <td>4</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/478925</td>
      <td>http://www.dailydemocrat.com/20130106/aurora-s...</td>
      <td>False</td>
      <td>...</td>
      <td>-104.8020</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::29||1::33||2::56||3::33</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Female||1::Male||2::Male||3::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Subject-Su...</td>
      <td>http://denver.cbslocal.com/2013/01/06/officer-...</td>
      <td>40.0</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>478959</td>
      <td>2013-01-07</td>
      <td>North Carolina</td>
      <td>Greensboro</td>
      <td>307 Mourning Dove Terrace</td>
      <td>2</td>
      <td>2</td>
      <td>http://www.gunviolencearchive.org/incident/478959</td>
      <td>http://www.journalnow.com/news/local/article_d...</td>
      <td>False</td>
      <td>...</td>
      <td>-79.9569</td>
      <td>2.0</td>
      <td>Two firearms recovered. (Attempted) murder sui...</td>
      <td>0::18||1::46||2::14||3::47</td>
      <td>0::Adult 18+||1::Adult 18+||2::Teen 12-17||3::...</td>
      <td>0::Female||1::Male||2::Male||3::Female</td>
      <td>0::Victim||1::Victim||2::Victim||3::Subject-Su...</td>
      <td>http://myfox8.com/2013/01/08/update-mother-sho...</td>
      <td>62.0</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>478948</td>
      <td>2013-01-07</td>
      <td>Oklahoma</td>
      <td>Tulsa</td>
      <td>6000 block of South Owasso</td>
      <td>4</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/478948</td>
      <td>http://usnews.nbcnews.com/_news/2013/01/07/163...</td>
      <td>False</td>
      <td>...</td>
      <td>-95.9768</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::23||1::23||2::33||3::55</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Female||1::Female||2::Female||3::Female||4:...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.kjrh.com/news/local-news/4-found-sh...</td>
      <td>72.0</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>479363</td>
      <td>2013-01-19</td>
      <td>New Mexico</td>
      <td>Albuquerque</td>
      <td>2806 Long Lane</td>
      <td>5</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/479363</td>
      <td>http://hinterlandgazette.com/2013/01/pastor-gr...</td>
      <td>False</td>
      <td>...</td>
      <td>-106.7160</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>0::51||1::40||2::9||3::5||4::2||5::15</td>
      <td>0::Adult 18+||1::Adult 18+||2::Child 0-11||3::...</td>
      <td>0::Male||1::Female||2::Male||3::Female||4::Fem...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.cbsnews.com/news/nehemiah-gringo-ca...</td>
      <td>10.0</td>
      <td>14.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>479374</td>
      <td>2013-01-21</td>
      <td>Louisiana</td>
      <td>New Orleans</td>
      <td>LaSalle Street and Martin Luther King Jr. Boul...</td>
      <td>0</td>
      <td>5</td>
      <td>http://www.gunviolencearchive.org/incident/479374</td>
      <td>http://www.nola.com/crime/index.ssf/2013/01/no...</td>
      <td>False</td>
      <td>...</td>
      <td>-90.0836</td>
      <td>NaN</td>
      <td>Unprovoked drive-by results in multiple teens ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.huffingtonpost.com/2013/01/21/new-o...</td>
      <td>93.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>479389</td>
      <td>2013-01-21</td>
      <td>California</td>
      <td>Brentwood</td>
      <td>1100 block of Breton Drive</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/479389</td>
      <td>http://sanfrancisco.cbslocal.com/2013/01/22/4-...</td>
      <td>False</td>
      <td>...</td>
      <td>-121.7180</td>
      <td>NaN</td>
      <td>Perps were likely motivated by gang affliations</td>
      <td>NaN</td>
      <td>0::Teen 12-17||1::Teen 12-17||2::Teen 12-17||4...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.contracostatimes.com/ci_22426767/br...</td>
      <td>11.0</td>
      <td>7.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>492151</td>
      <td>2013-01-23</td>
      <td>Maryland</td>
      <td>Baltimore</td>
      <td>1500 block of W. Fayette St.</td>
      <td>1</td>
      <td>6</td>
      <td>http://www.gunviolencearchive.org/incident/492151</td>
      <td>http://www.abc2news.com/news/crime-checker/bal...</td>
      <td>False</td>
      <td>...</td>
      <td>-76.6412</td>
      <td>NaN</td>
      <td>Shooting occurred over illegal dice game; vict...</td>
      <td>0::15</td>
      <td>0::Teen 12-17||1::Adult 18+||2::Adult 18+||3::...</td>
      <td>0::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://articles.baltimoresun.com/2013-08-25/ne...</td>
      <td>NaN</td>
      <td>44.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>491674</td>
      <td>2013-01-23</td>
      <td>Tennessee</td>
      <td>Chattanooga</td>
      <td>1501 Dodds Ave</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/491674</td>
      <td>http://www.wrcbtv.com/story/22664154/one-dead-...</td>
      <td>False</td>
      <td>...</td>
      <td>-85.2697</td>
      <td>1.0</td>
      <td>19 yr. old male dies; 3 inured; shooting on Do...</td>
      <td>0::19</td>
      <td>0::Adult 18+</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.wrcbtv.com/story/22664154/one-dead-...</td>
      <td>28.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>479413</td>
      <td>2013-01-25</td>
      <td>Missouri</td>
      <td>Saint Louis</td>
      <td>W Florissant Ave and Riverview Blvd</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/479413</td>
      <td>http://stlouis.cbslocal.com/2013/01/25/one-dea...</td>
      <td>False</td>
      <td>...</td>
      <td>-90.2494</td>
      <td>1.0</td>
      <td>38.706732, -90.249375</td>
      <td>0::28</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://fox2now.com/2013/01/25/two-shot-in-nort...</td>
      <td>76.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>479561</td>
      <td>2013-01-26</td>
      <td>Louisiana</td>
      <td>Charenton</td>
      <td>1000 block of Flat Town Road</td>
      <td>2</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/479561</td>
      <td>http://www.huffingtonpost.com/2013/01/27/wilbe...</td>
      <td>False</td>
      <td>...</td>
      <td>-91.5251</td>
      <td>1.0</td>
      <td>Ofc. hailed from Chitimacha Tribe of Louisiana...</td>
      <td>3::78||4::48</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://theadvocate.com/home/5018249-125/3-law-...</td>
      <td>50.0</td>
      <td>21.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>479554</td>
      <td>2013-01-26</td>
      <td>District of Columbia</td>
      <td>Washington</td>
      <td>2403 Benning Road Northeast</td>
      <td>0</td>
      <td>5</td>
      <td>http://www.gunviolencearchive.org/incident/479554</td>
      <td>http://www.washingtontimes.com/news/2013/jan/2...</td>
      <td>False</td>
      <td>...</td>
      <td>-76.9717</td>
      <td>1.0</td>
      <td>Media accounts conflict as to gender of victim...</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Female||1::Female||2::Male||3::Male||4::Mal...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.washingtonexaminer.com/d.c.-nightcl...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>14</th>
      <td>479460</td>
      <td>2013-01-26</td>
      <td>Ohio</td>
      <td>Springfield</td>
      <td>601 West Main Street</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/479460</td>
      <td>http://www.whio.com//news/news/crime-law/arres...</td>
      <td>False</td>
      <td>...</td>
      <td>-83.8218</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::34||1::28||2::23||3::29||4::29</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.daytondailynews.com/news/news/1-dea...</td>
      <td>79.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>479573</td>
      <td>2013-02-02</td>
      <td>Tennessee</td>
      <td>Memphis</td>
      <td>2514 Mount Moriah</td>
      <td>0</td>
      <td>5</td>
      <td>http://www.gunviolencearchive.org/incident/479573</td>
      <td>https://www.highbeam.com/doc/1P2-34349822.html</td>
      <td>False</td>
      <td>...</td>
      <td>-89.8871</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>5::24</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||4::A...</td>
      <td>0::Female||1::Female||2::Female||3::Female||4:...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://wreg.com/2013/02/02/five-hurt-in-memphi...</td>
      <td>84.0</td>
      <td>33.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>479580</td>
      <td>2013-02-03</td>
      <td>California</td>
      <td>Yuba (county)</td>
      <td>5800 block of Poplar Avenue</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/479580</td>
      <td>http://sacramento.cbslocal.com/2013/02/04/1-de...</td>
      <td>False</td>
      <td>...</td>
      <td>-121.5830</td>
      <td>1.0</td>
      <td>perps have gang affiliation, but unclear as to...</td>
      <td>0::20||4::25||5::18||6::19</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Female||4::Male||5::Male|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://news.asiantown.net/r/28306/no-death-pen...</td>
      <td>3.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>479592</td>
      <td>2013-02-07</td>
      <td>Illinois</td>
      <td>Chicago</td>
      <td>2500 block of East 75th Street</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/479592</td>
      <td>http://chicago.cbslocal.com/2013/02/07/four-wo...</td>
      <td>False</td>
      <td>...</td>
      <td>-87.5628</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::18||1::41||2::28||3::28</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://crimeinchicago.blogspot.com/2013/02/4-m...</td>
      <td>25.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>479603</td>
      <td>2013-02-09</td>
      <td>Louisiana</td>
      <td>New Orleans</td>
      <td>400 block of Bourbon Street</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/479603</td>
      <td>http://www.nola.com/crime/index.ssf/2013/04/su...</td>
      <td>False</td>
      <td>...</td>
      <td>-90.0676</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::18||1::22||2::21||3::29||4::19||5::22||6::23</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Female||2::Female||3::Male||4::Mal...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.cbsnews.com/news/mardi-gras-shootin...</td>
      <td>93.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>480311</td>
      <td>2013-02-11</td>
      <td>California</td>
      <td>Vallejo</td>
      <td>800 block of Humboldt Street</td>
      <td>1</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/480311</td>
      <td>http://archive.news10.net/news/article/229997/...</td>
      <td>False</td>
      <td>...</td>
      <td>-122.2280</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::22</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Female||4::Female</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.timesheraldonline.com/article/ZZ/20...</td>
      <td>14.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>480327</td>
      <td>2013-02-11</td>
      <td>Delaware</td>
      <td>Wilmington</td>
      <td>500 North King Street</td>
      <td>3</td>
      <td>2</td>
      <td>http://www.gunviolencearchive.org/incident/480327</td>
      <td>http://www.philly.com/philly/news/Police_ID_vi...</td>
      <td>False</td>
      <td>...</td>
      <td>-75.5499</td>
      <td>1.0</td>
      <td>M/S was both succesful and not - perp killed t...</td>
      <td>1::39||4::68</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Female||1::Female||2::Male||3::Male||4::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.usatoday.com/story/news/nation/2013...</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>21</th>
      <td>480344</td>
      <td>2013-02-12</td>
      <td>Utah</td>
      <td>Midvale</td>
      <td>8286 Adams Street and 450 West Street</td>
      <td>4</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/480344</td>
      <td>NaN</td>
      <td>False</td>
      <td>...</td>
      <td>-111.9030</td>
      <td>NaN</td>
      <td>Occured at "known narcotics house," suggesting...</td>
      <td>0::35||1::34||2::26||4::25</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Female||4::Male|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://fox13now.com/2014/03/28/man-sentenced-f...</td>
      <td>44.0</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>22</th>
      <td>480358</td>
      <td>2013-02-19</td>
      <td>California</td>
      <td>Orange (county)</td>
      <td>Katella Avenue</td>
      <td>4</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/480358</td>
      <td>http://www.dailymail.co.uk/news/article-228117...</td>
      <td>False</td>
      <td>...</td>
      <td>-117.9430</td>
      <td>1.0</td>
      <td>Aoki killed in Ladera Ranch; 3 vics shot while...</td>
      <td>0::20||4::69||5::27||6::20</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Female||4::Male||5::Male||6::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.nydailynews.com/news/national/2-sou...</td>
      <td>72.0</td>
      <td>34.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>480383</td>
      <td>2013-02-21</td>
      <td>Oklahoma</td>
      <td>Tulsa</td>
      <td>1200 block of North 89th East Avenue</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/480383</td>
      <td>http://www.krmg.com/news/news/local/more-detai...</td>
      <td>False</td>
      <td>...</td>
      <td>-95.8778</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::18||1::18||2::18||3::19||4::41</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Female||4::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.kjrh.com/news/local-news/suspect-in...</td>
      <td>77.0</td>
      <td>34.0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>480401</td>
      <td>2013-02-22</td>
      <td>Michigan</td>
      <td>Grand Rapids</td>
      <td>1447 Grandville Ave. SW</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/480401</td>
      <td>http://www.mlive.com/news/grand-rapids/index.s...</td>
      <td>False</td>
      <td>...</td>
      <td>-85.6853</td>
      <td>NaN</td>
      <td>One source article says there were five victim...</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Female</td>
      <td>0::Subject-Suspect||1::Victim||2::Victim||3::V...</td>
      <td>http://www.mlive.com/news/grand-rapids/index.s...</td>
      <td>76.0</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>25</th>
      <td>480407</td>
      <td>2013-02-23</td>
      <td>California</td>
      <td>Lancaster</td>
      <td>43145 Business Center Parkway</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/480407</td>
      <td>http://latimesblogs.latimes.com/lanow/2013/02/...</td>
      <td>False</td>
      <td>...</td>
      <td>-118.1310</td>
      <td>NaN</td>
      <td>Perps fire gun into crowd following altercatio...</td>
      <td>0::22||1::26||2::29||3::37</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://losangeles.cbslocal.com/2013/02/23/4-wo...</td>
      <td>36.0</td>
      <td>21.0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>480443</td>
      <td>2013-02-24</td>
      <td>Georgia</td>
      <td>Macon</td>
      <td>2800 block of Mercer University Drive</td>
      <td>0</td>
      <td>8</td>
      <td>http://www.gunviolencearchive.org/incident/480443</td>
      <td>http://www.macon.com/news/local/crime/article3...</td>
      <td>False</td>
      <td>...</td>
      <td>-83.6704</td>
      <td>NaN</td>
      <td>Perp's brother, Adrian, also initially charged...</td>
      <td>8::29</td>
      <td>0::Adult 18+||2::Adult 18+||3::Adult 18+||4::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male||5...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.macon.com/news/local/crime/article3...</td>
      <td>142.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>481186</td>
      <td>2013-03-02</td>
      <td>Louisiana</td>
      <td>Shreveport</td>
      <td>7000 block of Burlingame Boulevard</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/481186</td>
      <td>http://www.shreveportla.gov/DocumentCenter/Vie...</td>
      <td>False</td>
      <td>...</td>
      <td>-93.7726</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::18||1::18||2::18||3::19||4::15||5::17</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male||5...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.ksla.com/story/21442631/1-dead-3-in...</td>
      <td>3.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>481198</td>
      <td>2013-03-03</td>
      <td>Georgia</td>
      <td>Moultrie</td>
      <td>224 Second Street Northwest</td>
      <td>2</td>
      <td>2</td>
      <td>http://www.gunviolencearchive.org/incident/481198</td>
      <td>http://www.moultrieobserver.com/news/jury-says...</td>
      <td>False</td>
      <td>...</td>
      <td>-83.7912</td>
      <td>1.0</td>
      <td>Williams later acquitted on his charges</td>
      <td>0::50||1::42||4::24||5::25</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Female||3::Male||4::Male|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.moultrieobserver.com/news/local_new...</td>
      <td>172.0</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>481208</td>
      <td>2013-03-03</td>
      <td>Michigan</td>
      <td>Saginaw (county)</td>
      <td>4030 Dixie Hwy</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/481208</td>
      <td>http://www.mlive.com/news/saginaw/index.ssf/20...</td>
      <td>False</td>
      <td>...</td>
      <td>-83.9082</td>
      <td>NaN</td>
      <td>Vics appear to be bystanders caught in crossfi...</td>
      <td>0::23||1::34||2::17||3::25</td>
      <td>0::Adult 18+||1::Adult 18+||2::Teen 12-17||3::...</td>
      <td>0::Male||1::Male||2::Female||3::Female</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim</td>
      <td>http://www.wfxg.com/story/21447002/four-people...</td>
      <td>95.0</td>
      <td>32.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>239647</th>
      <td>1081936</td>
      <td>2018-03-31</td>
      <td>Maine</td>
      <td>Bangor</td>
      <td>Ohio St</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.newscentermaine.com/article/news/lo...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>poss shots fired during dv, arrest on W Broadw...</td>
      <td>0::20</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Subject-Suspect</td>
      <td>http://www.newscentermaine.com/article/news/lo...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239648</th>
      <td>1081946</td>
      <td>2018-03-31</td>
      <td>District of Columbia</td>
      <td>Washington</td>
      <td>600 block of Alabama Ave SE</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://twitter.com/DCPoliceDept/status/980251...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/DCPoliceDept/status/980251...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239649</th>
      <td>1081949</td>
      <td>2018-03-31</td>
      <td>Nevada</td>
      <td>Las Vegas</td>
      <td>Bonanza Rd and Valley View Blvd</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.ktnv.com/news/crime/3-injured-afte...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Subject-Suspect</td>
      <td>https://www.ktnv.com/news/crime/3-injured-afte...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239650</th>
      <td>1082266</td>
      <td>2018-03-31</td>
      <td>California</td>
      <td>Palmdale</td>
      <td>37900 block of 47th St E</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://local.nixle.com/alert/6489381/?sub_id=...</td>
      <td>False</td>
      <td>...</td>
      <td>-118.0450</td>
      <td>1.0</td>
      <td>gunshot wound to the upper torso.</td>
      <td>0::35</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://ktla.com/2018/04/01/l-a-county-sheriffs...</td>
      <td>36.0</td>
      <td>21.0</td>
    </tr>
    <tr>
      <th>239651</th>
      <td>1082483</td>
      <td>2018-03-31</td>
      <td>Texas</td>
      <td>Wichita Falls</td>
      <td>2300 block of 8th St</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.newschannel6now.com/story/37853540/...</td>
      <td>False</td>
      <td>...</td>
      <td>-98.5151</td>
      <td>1.0</td>
      <td>poss SD, poss drug deal gone wrong</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://www.newschannel6now.com/story/37853540/...</td>
      <td>69.0</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>239652</th>
      <td>1082486</td>
      <td>2018-03-31</td>
      <td>Texas</td>
      <td>Dallas</td>
      <td>1200 block of Whispering Trail</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.dallasnews.com/news/crime/2018/03/...</td>
      <td>False</td>
      <td>...</td>
      <td>-96.8059</td>
      <td>1.0</td>
      <td>hi, shot suspect in leg, failed ar</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>1::Male</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>https://www.dallasnews.com/news/crime/2018/03/...</td>
      <td>109.0</td>
      <td>23.0</td>
    </tr>
    <tr>
      <th>239653</th>
      <td>1083121</td>
      <td>2018-03-31</td>
      <td>Nevada</td>
      <td>Reno</td>
      <td>1400 E Peckham Ln</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://lasvegassun.com/news/2018/apr/02/burgl...</td>
      <td>False</td>
      <td>...</td>
      <td>-119.7800</td>
      <td>1.0</td>
      <td>respond to ar, shot subject</td>
      <td>0::21</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Subject-Suspect</td>
      <td>https://www.rgj.com/story/news/crime/2018/04/0...</td>
      <td>26.0</td>
      <td>16.0</td>
    </tr>
    <tr>
      <th>239654</th>
      <td>1081947</td>
      <td>2018-03-31</td>
      <td>Nevada</td>
      <td>Reno</td>
      <td>Wedekind Rd</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://mynews4.com/news/local/police-28-year-o...</td>
      <td>False</td>
      <td>...</td>
      <td>-119.7760</td>
      <td>1.0</td>
      <td>apartment building, self inflict, unclear if A...</td>
      <td>0::28</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Victim</td>
      <td>https://www.rgj.com/story/news/crime/2018/03/3...</td>
      <td>30.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>239655</th>
      <td>1082089</td>
      <td>2018-03-31</td>
      <td>California</td>
      <td>San Diego</td>
      <td>8660 Miramar Rd</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.nbcsandiego.com/news/local/Suspect...</td>
      <td>False</td>
      <td>...</td>
      <td>-117.1360</td>
      <td>1.0</td>
      <td>patron shot at bouncer 13 times and missed</td>
      <td>NaN</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Subject-Suspect</td>
      <td>http://www.cbs8.com/story/37852105/man-fires-s...</td>
      <td>77.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>239656</th>
      <td>1081901</td>
      <td>2018-03-31</td>
      <td>New York</td>
      <td>Rochester</td>
      <td>100 block of Warren Ave</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://twitter.com/mcfw/status/98013667377747...</td>
      <td>False</td>
      <td>...</td>
      <td>-77.5617</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Female</td>
      <td>0::Victim</td>
      <td>https://twitter.com/mcfw/status/98013667377747...</td>
      <td>136.0</td>
      <td>56.0</td>
    </tr>
    <tr>
      <th>239657</th>
      <td>1082394</td>
      <td>2018-03-31</td>
      <td>California</td>
      <td>Shafter</td>
      <td>300 block of Atlantic Ave</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.bakersfield.com/news/breaking/none-...</td>
      <td>False</td>
      <td>...</td>
      <td>-119.2830</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::55</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Subject-Suspect</td>
      <td>http://www.bakersfield.com/news/breaking/none-...</td>
      <td>32.0</td>
      <td>14.0</td>
    </tr>
    <tr>
      <th>239658</th>
      <td>1082392</td>
      <td>2018-03-31</td>
      <td>California</td>
      <td>Oakland</td>
      <td>1700 block of 23rd Ave</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.eastbaytimes.com/2018/04/01/man-fa...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::29</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Victim</td>
      <td>https://www.eastbaytimes.com/2018/04/01/man-fa...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239659</th>
      <td>1082057</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Orlando</td>
      <td>South Kirkman Road and Raleigh Street</td>
      <td>0</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.orlandosentinel.com/news/breaking-n...</td>
      <td>False</td>
      <td>...</td>
      <td>-81.4594</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+</td>
      <td>NaN</td>
      <td>0::Victim||1::Victim||2::Victim</td>
      <td>http://www.orlandosentinel.com/news/breaking-n...</td>
      <td>46.0</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>239660</th>
      <td>1082091</td>
      <td>2018-03-31</td>
      <td>California</td>
      <td>Stockton</td>
      <td>1700 block of Harbor St</td>
      <td>2</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.recordnet.com/news/20180401/victims...</td>
      <td>False</td>
      <td>...</td>
      <td>-121.3140</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::20||1::22</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>0::Victim||1::Victim</td>
      <td>http://www.recordnet.com/news/20180331/two-sho...</td>
      <td>13.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>239661</th>
      <td>1081719</td>
      <td>2018-03-31</td>
      <td>North Carolina</td>
      <td>Kings Mountain</td>
      <td>US 74</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.wsoctv.com/news/local/4-shot-in-dr...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim</td>
      <td>http://www.wbtv.com/story/37851749/four-people...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239662</th>
      <td>1082388</td>
      <td>2018-03-31</td>
      <td>Minnesota</td>
      <td>Saint Paul</td>
      <td>1000 block of York Ave</td>
      <td>0</td>
      <td>2</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.twincities.com/2018/04/01/drive-by...</td>
      <td>False</td>
      <td>...</td>
      <td>-93.0609</td>
      <td>1.0</td>
      <td>shot while sitting in car</td>
      <td>0::18||1::22</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>0::Victim||1::Victim</td>
      <td>http://www.kare11.com/article/news/2-injured-i...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239663</th>
      <td>1082197</td>
      <td>2018-03-31</td>
      <td>Oklahoma</td>
      <td>Guthrie</td>
      <td>500 block of Walnut St</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://okcfox.com/news/local/one-person-killed...</td>
      <td>False</td>
      <td>...</td>
      <td>-97.4163</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::27</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Subject-Suspect</td>
      <td>http://www.news9.com/story/37853411/officials-...</td>
      <td>31.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>239664</th>
      <td>1082023</td>
      <td>2018-03-31</td>
      <td>Missouri</td>
      <td>Festus</td>
      <td>4200 block of Hillsboro Hematite Rd</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.kmov.com/story/37854762/woman-63-sh...</td>
      <td>False</td>
      <td>...</td>
      <td>-90.4990</td>
      <td>1.0</td>
      <td>Victim grazed in head while handing out flyers.</td>
      <td>0::63||1::22</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Female||1::Male</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://www.ksdk.com/article/news/local/police-...</td>
      <td>114.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>239665</th>
      <td>1082226</td>
      <td>2018-03-31</td>
      <td>Missouri</td>
      <td>Saint Clair</td>
      <td>1100 Park Dr</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://fox2now.com/2018/04/01/franklin-county-...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>Victim shot in chest prior to police arrival; ...</td>
      <td>0::31||1::56</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://fox2now.com/2018/04/01/franklin-county-...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239666</th>
      <td>1081894</td>
      <td>2018-03-31</td>
      <td>Missouri</td>
      <td>Saint Louis</td>
      <td>3100 block of California St</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.stltoday.com/news/local/crime-and-c...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>Child fatally shot by younger brother.</td>
      <td>0::7||1::5</td>
      <td>0::Child 0-11||1::Child 0-11</td>
      <td>0::Male||1::Male</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://fox2now.com/2018/03/31/7-year-old-dies-...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239667</th>
      <td>1082234</td>
      <td>2018-03-31</td>
      <td>Tennessee</td>
      <td>Memphis</td>
      <td>2900 block of Wingate</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://wreg.com/2018/03/31/one-person-in-criti...</td>
      <td>False</td>
      <td>...</td>
      <td>-89.9872</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::69||1::35</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Female</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://wreg.com/2018/03/31/one-person-in-criti...</td>
      <td>90.0</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>239668</th>
      <td>1081742</td>
      <td>2018-03-31</td>
      <td>Michigan</td>
      <td>Detroit</td>
      <td>I-96</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.freep.com/story/news/local/michiga...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>near Wyoming St</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male</td>
      <td>0::Victim</td>
      <td>https://www.freep.com/story/news/local/michiga...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239669</th>
      <td>1082990</td>
      <td>2018-03-31</td>
      <td>Wisconsin</td>
      <td>Madison</td>
      <td>Hayes Rd</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.channel3000.com/news/crime/couple-...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>.45 shell casing recovered</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>http://host.madison.com/wsj/news/local/crime/g...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239670</th>
      <td>1081752</td>
      <td>2018-03-31</td>
      <td>Illinois</td>
      <td>Chicago</td>
      <td>1 block of N Paulina St</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://chicago.suntimes.com/news/man-36-wound...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>Rt. leg, good; walk-up by 1;</td>
      <td>0::36</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>https://chicago.suntimes.com/news/man-36-wound...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239671</th>
      <td>1082061</td>
      <td>2018-03-31</td>
      <td>Washington</td>
      <td>Spokane (Spokane Valley)</td>
      <td>12600 block of N Willow Crest Ln</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.kxly.com/news/domestic-violence-su...</td>
      <td>False</td>
      <td>...</td>
      <td>-117.2350</td>
      <td>1.0</td>
      <td>DV call leads to seizure of firearms during ar...</td>
      <td>0::48</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Subject-Suspect</td>
      <td>https://www.kxly.com/news/domestic-violence-su...</td>
      <td>4.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>239672</th>
      <td>1083142</td>
      <td>2018-03-31</td>
      <td>Louisiana</td>
      <td>Rayne</td>
      <td>North Riceland Road and Highway 90</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.klfy.com/news/local/rayne-woman-cha...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::25</td>
      <td>0::Adult 18+</td>
      <td>0::Female</td>
      <td>0::Subject-Suspect</td>
      <td>http://www.klfy.com/news/local/rayne-woman-cha...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239673</th>
      <td>1083139</td>
      <td>2018-03-31</td>
      <td>Louisiana</td>
      <td>Natchitoches</td>
      <td>247 Keyser Ave</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.ksla.com/story/37854648/man-wanted-...</td>
      <td>False</td>
      <td>...</td>
      <td>-93.0836</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>1::21</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://www.ksla.com/story/37854648/man-wanted-...</td>
      <td>23.0</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>239674</th>
      <td>1083151</td>
      <td>2018-03-31</td>
      <td>Louisiana</td>
      <td>Gretna</td>
      <td>1300 block of Cook Street</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.nola.com/crime/index.ssf/2018/04/sh...</td>
      <td>False</td>
      <td>...</td>
      <td>-90.0442</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::21</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Victim</td>
      <td>http://www.nola.com/crime/index.ssf/2018/04/sh...</td>
      <td>85.0</td>
      <td>7.0</td>
    </tr>
    <tr>
      <th>239675</th>
      <td>1082514</td>
      <td>2018-03-31</td>
      <td>Texas</td>
      <td>Houston</td>
      <td>12630 Ashford Point Dr</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.chron.com/news/houston-texas/houst...</td>
      <td>False</td>
      <td>...</td>
      <td>-95.6110</td>
      <td>1.0</td>
      <td>Vic was found shot to death in car on 4/1/18, ...</td>
      <td>0::42</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Victim</td>
      <td>http://www.khou.com/article/news/hpd-investiga...</td>
      <td>149.0</td>
      <td>17.0</td>
    </tr>
    <tr>
      <th>239676</th>
      <td>1081940</td>
      <td>2018-03-31</td>
      <td>Maine</td>
      <td>Norridgewock</td>
      <td>434 Skowhegan Rd</td>
      <td>2</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.centralmaine.com/2018/03/31/police...</td>
      <td>False</td>
      <td>...</td>
      <td>-69.7691</td>
      <td>2.0</td>
      <td>ALT: US 2, shot wife then self, handgun, shotg...</td>
      <td>0::58||1::62</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Female||1::Male</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>https://www.centralmaine.com/2018/03/31/police...</td>
      <td>111.0</td>
      <td>3.0</td>
    </tr>
  </tbody>
</table>
<p>239677 rows × 26 columns</p>
</div>




```python
df.drop(columns=['notes', 'participant_age_group','incident_url_fields_missing','participant_relationship','sources','incident_url','source_url','congressional_district','location_description','longitude'], axis=1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>incident_id</th>
      <th>date</th>
      <th>state</th>
      <th>city_or_county</th>
      <th>address</th>
      <th>n_killed</th>
      <th>n_injured</th>
      <th>gun_stolen</th>
      <th>gun_type</th>
      <th>incident_characteristics</th>
      <th>latitude</th>
      <th>n_guns_involved</th>
      <th>participant_age</th>
      <th>participant_gender</th>
      <th>participant_name</th>
      <th>participant_status</th>
      <th>participant_type</th>
      <th>state_house_district</th>
      <th>state_senate_district</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>461105</td>
      <td>2013-01-01</td>
      <td>Pennsylvania</td>
      <td>Mckeesport</td>
      <td>1506 Versailles Avenue and Coursin Street</td>
      <td>0</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Mass Shooting (4+ vict...</td>
      <td>40.3467</td>
      <td>NaN</td>
      <td>0::20</td>
      <td>0::Male||1::Male||3::Male||4::Female</td>
      <td>0::Julian Sims</td>
      <td>0::Arrested||1::Injured||2::Injured||3::Injure...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>460726</td>
      <td>2013-01-01</td>
      <td>California</td>
      <td>Hawthorne</td>
      <td>13500 block of Cerise Avenue</td>
      <td>1</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>33.9090</td>
      <td>NaN</td>
      <td>0::20</td>
      <td>0::Male</td>
      <td>0::Bernard Gillis</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>62.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>478855</td>
      <td>2013-01-01</td>
      <td>Ohio</td>
      <td>Lorain</td>
      <td>1776 East 28th Street</td>
      <td>1</td>
      <td>3</td>
      <td>0::Unknown||1::Unknown</td>
      <td>0::Unknown||1::Unknown</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>41.4455</td>
      <td>2.0</td>
      <td>0::25||1::31||2::33||3::34||4::33</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Damien Bell||1::Desmen Noble||2::Herman Sea...</td>
      <td>0::Injured, Unharmed, Arrested||1::Unharmed, A...</td>
      <td>0::Subject-Suspect||1::Subject-Suspect||2::Vic...</td>
      <td>56.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>478925</td>
      <td>2013-01-05</td>
      <td>Colorado</td>
      <td>Aurora</td>
      <td>16000 block of East Ithaca Place</td>
      <td>4</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Dead (murder, accidental, suicide)||Off...</td>
      <td>39.6518</td>
      <td>NaN</td>
      <td>0::29||1::33||2::56||3::33</td>
      <td>0::Female||1::Male||2::Male||3::Male</td>
      <td>0::Stacie Philbrook||1::Christopher Ratliffe||...</td>
      <td>0::Killed||1::Killed||2::Killed||3::Killed</td>
      <td>0::Victim||1::Victim||2::Victim||3::Subject-Su...</td>
      <td>40.0</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>478959</td>
      <td>2013-01-07</td>
      <td>North Carolina</td>
      <td>Greensboro</td>
      <td>307 Mourning Dove Terrace</td>
      <td>2</td>
      <td>2</td>
      <td>0::Unknown||1::Unknown</td>
      <td>0::Handgun||1::Handgun</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>36.1140</td>
      <td>2.0</td>
      <td>0::18||1::46||2::14||3::47</td>
      <td>0::Female||1::Male||2::Male||3::Female</td>
      <td>0::Danielle Imani Jameison||1::Maurice Eugene ...</td>
      <td>0::Injured||1::Injured||2::Killed||3::Killed</td>
      <td>0::Victim||1::Victim||2::Victim||3::Subject-Su...</td>
      <td>62.0</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>478948</td>
      <td>2013-01-07</td>
      <td>Oklahoma</td>
      <td>Tulsa</td>
      <td>6000 block of South Owasso</td>
      <td>4</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Dead (murder, accidental, suicide)||Hom...</td>
      <td>36.2405</td>
      <td>NaN</td>
      <td>0::23||1::23||2::33||3::55</td>
      <td>0::Female||1::Female||2::Female||3::Female||4:...</td>
      <td>0::Rebeika Powell||1::Kayetie Melchor||2::Mist...</td>
      <td>0::Killed||1::Killed||2::Killed||3::Killed||4:...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>72.0</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>479363</td>
      <td>2013-01-19</td>
      <td>New Mexico</td>
      <td>Albuquerque</td>
      <td>2806 Long Lane</td>
      <td>5</td>
      <td>0</td>
      <td>0::Unknown||1::Unknown</td>
      <td>0::22 LR||1::223 Rem [AR-15]</td>
      <td>Shot - Dead (murder, accidental, suicide)||Mas...</td>
      <td>34.9791</td>
      <td>2.0</td>
      <td>0::51||1::40||2::9||3::5||4::2||5::15</td>
      <td>0::Male||1::Female||2::Male||3::Female||4::Fem...</td>
      <td>0::Greg Griego||1::Sara Griego||2::Zephania Gr...</td>
      <td>0::Killed||1::Killed||2::Killed||3::Killed||4:...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>10.0</td>
      <td>14.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>479374</td>
      <td>2013-01-21</td>
      <td>Louisiana</td>
      <td>New Orleans</td>
      <td>LaSalle Street and Martin Luther King Jr. Boul...</td>
      <td>0</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Drive-by (car to stree...</td>
      <td>29.9435</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>93.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>479389</td>
      <td>2013-01-21</td>
      <td>California</td>
      <td>Brentwood</td>
      <td>1100 block of Breton Drive</td>
      <td>0</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Drive-by (car to stree...</td>
      <td>37.9656</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>11.0</td>
      <td>7.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>492151</td>
      <td>2013-01-23</td>
      <td>Maryland</td>
      <td>Baltimore</td>
      <td>1500 block of W. Fayette St.</td>
      <td>1</td>
      <td>6</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>39.2899</td>
      <td>NaN</td>
      <td>0::15</td>
      <td>0::Male</td>
      <td>0::Deshaun Jones</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>NaN</td>
      <td>44.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>491674</td>
      <td>2013-01-23</td>
      <td>Tennessee</td>
      <td>Chattanooga</td>
      <td>1501 Dodds Ave</td>
      <td>1</td>
      <td>3</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>35.0221</td>
      <td>1.0</td>
      <td>0::19</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>0::Demetrius Davis</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>28.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>479413</td>
      <td>2013-01-25</td>
      <td>Missouri</td>
      <td>Saint Louis</td>
      <td>W Florissant Ave and Riverview Blvd</td>
      <td>1</td>
      <td>3</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>38.7067</td>
      <td>1.0</td>
      <td>0::28</td>
      <td>0::Male</td>
      <td>0::Terry Robinson Jr.</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>76.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>479561</td>
      <td>2013-01-26</td>
      <td>Louisiana</td>
      <td>Charenton</td>
      <td>1000 block of Flat Town Road</td>
      <td>2</td>
      <td>3</td>
      <td>0::Unknown</td>
      <td>0::Shotgun</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>29.8816</td>
      <td>1.0</td>
      <td>3::78||4::48</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Ofc.||1::Dep.||2::Dep.||3::Eddie Lyons||4::...</td>
      <td>0::Killed||1::Injured||2::Injured||3::Killed||...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>50.0</td>
      <td>21.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>479554</td>
      <td>2013-01-26</td>
      <td>District of Columbia</td>
      <td>Washington</td>
      <td>2403 Benning Road Northeast</td>
      <td>0</td>
      <td>5</td>
      <td>0::Unknown</td>
      <td>0::Handgun</td>
      <td>Shot - Wounded/Injured||Mass Shooting (4+ vict...</td>
      <td>38.8978</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::Female||1::Female||2::Male||3::Male||4::Mal...</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>14</th>
      <td>479460</td>
      <td>2013-01-26</td>
      <td>Ohio</td>
      <td>Springfield</td>
      <td>601 West Main Street</td>
      <td>1</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>39.9252</td>
      <td>NaN</td>
      <td>0::34||1::28||2::23||3::29||4::29</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Ernest Edwards||1::Anthony Clark||2::Joshua...</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>79.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>479573</td>
      <td>2013-02-02</td>
      <td>Tennessee</td>
      <td>Memphis</td>
      <td>2514 Mount Moriah</td>
      <td>0</td>
      <td>5</td>
      <td>0::Unknown</td>
      <td>0::Handgun</td>
      <td>Shot - Wounded/Injured||Mass Shooting (4+ vict...</td>
      <td>35.0803</td>
      <td>1.0</td>
      <td>5::24</td>
      <td>0::Female||1::Female||2::Female||3::Female||4:...</td>
      <td>4::Mary||5::Sundra Payne</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>84.0</td>
      <td>33.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>479580</td>
      <td>2013-02-03</td>
      <td>California</td>
      <td>Yuba (county)</td>
      <td>5800 block of Poplar Avenue</td>
      <td>1</td>
      <td>3</td>
      <td>0::Unknown</td>
      <td>0::9mm</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>39.1236</td>
      <td>1.0</td>
      <td>0::20||4::25||5::18||6::19</td>
      <td>0::Male||1::Male||2::Female||4::Male||5::Male|...</td>
      <td>0::Teng Yang||1::Tou Yang||2::Xong Yang||3::Ya...</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>3.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>479592</td>
      <td>2013-02-07</td>
      <td>Illinois</td>
      <td>Chicago</td>
      <td>2500 block of East 75th Street</td>
      <td>0</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Drive-by (car to stree...</td>
      <td>41.7592</td>
      <td>NaN</td>
      <td>0::18||1::41||2::28||3::28</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>25.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>479603</td>
      <td>2013-02-09</td>
      <td>Louisiana</td>
      <td>New Orleans</td>
      <td>400 block of Bourbon Street</td>
      <td>0</td>
      <td>4</td>
      <td>0::Unknown</td>
      <td>0::Handgun</td>
      <td>Shot - Wounded/Injured||Mass Shooting (4+ vict...</td>
      <td>29.9563</td>
      <td>1.0</td>
      <td>0::18||1::22||2::21||3::29||4::19||5::22||6::23</td>
      <td>0::Male||1::Female||2::Female||3::Male||4::Mal...</td>
      <td>4::Malcolm "London" Hall||5::Brandon Brown||6:...</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>93.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>480311</td>
      <td>2013-02-11</td>
      <td>California</td>
      <td>Vallejo</td>
      <td>800 block of Humboldt Street</td>
      <td>1</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>38.1072</td>
      <td>NaN</td>
      <td>0::22</td>
      <td>0::Male||1::Male||2::Male||3::Female||4::Female</td>
      <td>0::Oscar Garcia</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>14.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>480327</td>
      <td>2013-02-11</td>
      <td>Delaware</td>
      <td>Wilmington</td>
      <td>500 North King Street</td>
      <td>3</td>
      <td>2</td>
      <td>0::Unknown</td>
      <td>0::45 Auto</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>39.7407</td>
      <td>1.0</td>
      <td>1::39||4::68</td>
      <td>0::Female||1::Female||2::Male||3::Male||4::Male</td>
      <td>0::Laura Elizabeth "Beth" Mulford||1::Christin...</td>
      <td>0::Killed||1::Killed||2::Injured||3::Injured||...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>21</th>
      <td>480344</td>
      <td>2013-02-12</td>
      <td>Utah</td>
      <td>Midvale</td>
      <td>8286 Adams Street and 450 West Street</td>
      <td>4</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>40.6008</td>
      <td>NaN</td>
      <td>0::35||1::34||2::26||4::25</td>
      <td>0::Male||1::Male||2::Male||3::Female||4::Male|...</td>
      <td>0::Omar Paul Jarman||1::Shontay N. Young||2::D...</td>
      <td>0::Killed||1::Killed||2::Killed||3::Injured||4...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>44.0</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>22</th>
      <td>480358</td>
      <td>2013-02-19</td>
      <td>California</td>
      <td>Orange (county)</td>
      <td>Katella Avenue</td>
      <td>4</td>
      <td>3</td>
      <td>0::Unknown</td>
      <td>0::12 gauge</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>33.8031</td>
      <td>1.0</td>
      <td>0::20||4::69||5::27||6::20</td>
      <td>0::Female||4::Male||5::Male||6::Male</td>
      <td>0::Courtney Aoki||4::Melvin Edwards||5::Jeremy...</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>72.0</td>
      <td>34.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>480383</td>
      <td>2013-02-21</td>
      <td>Oklahoma</td>
      <td>Tulsa</td>
      <td>1200 block of North 89th East Avenue</td>
      <td>1</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>36.1722</td>
      <td>NaN</td>
      <td>0::18||1::18||2::18||3::19||4::41</td>
      <td>0::Male||1::Male||2::Male||3::Female||4::Male</td>
      <td>0::Chaz Fain||4::Mark Hopkins</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>77.0</td>
      <td>34.0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>480401</td>
      <td>2013-02-22</td>
      <td>Michigan</td>
      <td>Grand Rapids</td>
      <td>1447 Grandville Ave. SW</td>
      <td>0</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Mass Shooting (4+ vict...</td>
      <td>42.9371</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Female</td>
      <td>0::Marcus Antoine Smith</td>
      <td>0::Unharmed, Arrested||1::Injured||2::Injured|...</td>
      <td>0::Subject-Suspect||1::Victim||2::Victim||3::V...</td>
      <td>76.0</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>25</th>
      <td>480407</td>
      <td>2013-02-23</td>
      <td>California</td>
      <td>Lancaster</td>
      <td>43145 Business Center Parkway</td>
      <td>0</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Mass Shooting (4+ vict...</td>
      <td>34.6666</td>
      <td>NaN</td>
      <td>0::22||1::26||2::29||3::37</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>36.0</td>
      <td>21.0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>480443</td>
      <td>2013-02-24</td>
      <td>Georgia</td>
      <td>Macon</td>
      <td>2800 block of Mercer University Drive</td>
      <td>0</td>
      <td>8</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Mass Shooting (4+ vict...</td>
      <td>32.8260</td>
      <td>NaN</td>
      <td>8::29</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male||5...</td>
      <td>8::Frank Fletcher, Jr.</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>142.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>481186</td>
      <td>2013-03-02</td>
      <td>Louisiana</td>
      <td>Shreveport</td>
      <td>7000 block of Burlingame Boulevard</td>
      <td>1</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>32.4420</td>
      <td>NaN</td>
      <td>0::18||1::18||2::18||3::19||4::15||5::17</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male||5...</td>
      <td>0::Chauncey "Trey" Boulevard, Jr.||1::Jumarco ...</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>3.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>481198</td>
      <td>2013-03-03</td>
      <td>Georgia</td>
      <td>Moultrie</td>
      <td>224 Second Street Northwest</td>
      <td>2</td>
      <td>2</td>
      <td>0::Unknown</td>
      <td>0::7.62 [AK-47]</td>
      <td>Shot - Wounded/Injured||Shot - Dead (murder, a...</td>
      <td>31.1824</td>
      <td>1.0</td>
      <td>0::50||1::42||4::24||5::25</td>
      <td>0::Male||1::Male||2::Female||3::Male||4::Male|...</td>
      <td>0::James L. Key||1::Eric Debruce||2::Margaret ...</td>
      <td>0::Killed||1::Killed||2::Injured||3::Injured||...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>172.0</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>481208</td>
      <td>2013-03-03</td>
      <td>Michigan</td>
      <td>Saginaw (county)</td>
      <td>4030 Dixie Hwy</td>
      <td>0</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Shot - Wounded/Injured||Mass Shooting (4+ vict...</td>
      <td>43.3944</td>
      <td>NaN</td>
      <td>0::23||1::34||2::17||3::25</td>
      <td>0::Male||1::Male||2::Female||3::Female</td>
      <td>1::Edgar G. Jones</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim</td>
      <td>95.0</td>
      <td>32.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>239647</th>
      <td>1081936</td>
      <td>2018-03-31</td>
      <td>Maine</td>
      <td>Bangor</td>
      <td>Ohio St</td>
      <td>0</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shots Fired - No Injuries||Domestic Violence</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0::20</td>
      <td>0::Male</td>
      <td>0::Garrett Field</td>
      <td>0::Unharmed, Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239648</th>
      <td>1081946</td>
      <td>2018-03-31</td>
      <td>District of Columbia</td>
      <td>Washington</td>
      <td>600 block of Alabama Ave SE</td>
      <td>0</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shots Fired - No Injuries</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239649</th>
      <td>1081949</td>
      <td>2018-03-31</td>
      <td>Nevada</td>
      <td>Las Vegas</td>
      <td>Bonanza Rd and Valley View Blvd</td>
      <td>0</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shots Fired - No Injuries||Home Invasion||Home...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>0::Unharmed, Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239650</th>
      <td>1082266</td>
      <td>2018-03-31</td>
      <td>California</td>
      <td>Palmdale</td>
      <td>37900 block of 47th St E</td>
      <td>1</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Dead (murder, accidental, suicide)</td>
      <td>34.5713</td>
      <td>1.0</td>
      <td>0::35</td>
      <td>0::Male||1::Male</td>
      <td>0::Israel Castaneda</td>
      <td>0::Killed||1::Unharmed</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>36.0</td>
      <td>21.0</td>
    </tr>
    <tr>
      <th>239651</th>
      <td>1082483</td>
      <td>2018-03-31</td>
      <td>Texas</td>
      <td>Wichita Falls</td>
      <td>2300 block of 8th St</td>
      <td>0</td>
      <td>1</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured||Defensive Use||Defensi...</td>
      <td>33.9052</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::Male||1::Male</td>
      <td>NaN</td>
      <td>0::Unharmed||1::Injured</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>69.0</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>239652</th>
      <td>1082486</td>
      <td>2018-03-31</td>
      <td>Texas</td>
      <td>Dallas</td>
      <td>1200 block of Whispering Trail</td>
      <td>0</td>
      <td>1</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured||Home Invasion||Home In...</td>
      <td>32.6772</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>1::Male</td>
      <td>NaN</td>
      <td>0::Unharmed||1::Injured</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>109.0</td>
      <td>23.0</td>
    </tr>
    <tr>
      <th>239653</th>
      <td>1083121</td>
      <td>2018-03-31</td>
      <td>Nevada</td>
      <td>Reno</td>
      <td>1400 E Peckham Ln</td>
      <td>1</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Dead (murder, accidental, suicide)||Ins...</td>
      <td>39.4832</td>
      <td>1.0</td>
      <td>0::21</td>
      <td>0::Male</td>
      <td>0::Nicholas Sedano</td>
      <td>0::Killed</td>
      <td>0::Subject-Suspect</td>
      <td>26.0</td>
      <td>16.0</td>
    </tr>
    <tr>
      <th>239654</th>
      <td>1081947</td>
      <td>2018-03-31</td>
      <td>Nevada</td>
      <td>Reno</td>
      <td>Wedekind Rd</td>
      <td>1</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Dead (murder, accidental, suicide)||Sui...</td>
      <td>39.5537</td>
      <td>1.0</td>
      <td>0::28</td>
      <td>0::Male</td>
      <td>0::Julio Ramos Rubalcaba</td>
      <td>0::Killed</td>
      <td>0::Victim</td>
      <td>30.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>239655</th>
      <td>1082089</td>
      <td>2018-03-31</td>
      <td>California</td>
      <td>San Diego</td>
      <td>8660 Miramar Rd</td>
      <td>0</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Institution/Group/Business||Shots Fired - No I...</td>
      <td>32.8936</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>0::Unharmed</td>
      <td>0::Subject-Suspect</td>
      <td>77.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>239656</th>
      <td>1081901</td>
      <td>2018-03-31</td>
      <td>New York</td>
      <td>Rochester</td>
      <td>100 block of Warren Ave</td>
      <td>1</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Dead (murder, accidental, suicide)||Sui...</td>
      <td>43.1076</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::Female</td>
      <td>NaN</td>
      <td>0::Killed</td>
      <td>0::Victim</td>
      <td>136.0</td>
      <td>56.0</td>
    </tr>
    <tr>
      <th>239657</th>
      <td>1082394</td>
      <td>2018-03-31</td>
      <td>California</td>
      <td>Shafter</td>
      <td>300 block of Atlantic Ave</td>
      <td>0</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shots Fired - No Injuries||Officer Involved In...</td>
      <td>35.5019</td>
      <td>1.0</td>
      <td>0::55</td>
      <td>0::Male</td>
      <td>0::John Wells</td>
      <td>0::Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>32.0</td>
      <td>14.0</td>
    </tr>
    <tr>
      <th>239658</th>
      <td>1082392</td>
      <td>2018-03-31</td>
      <td>California</td>
      <td>Oakland</td>
      <td>1700 block of 23rd Ave</td>
      <td>1</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Dead (murder, accidental, suicide)</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0::29</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>0::Killed</td>
      <td>0::Victim</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239659</th>
      <td>1082057</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Orlando</td>
      <td>South Kirkman Road and Raleigh Street</td>
      <td>0</td>
      <td>3</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured</td>
      <td>28.5279</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured</td>
      <td>0::Victim||1::Victim||2::Victim</td>
      <td>46.0</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>239660</th>
      <td>1082091</td>
      <td>2018-03-31</td>
      <td>California</td>
      <td>Stockton</td>
      <td>1700 block of Harbor St</td>
      <td>2</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Dead (murder, accidental, suicide)</td>
      <td>37.9478</td>
      <td>1.0</td>
      <td>0::20||1::22</td>
      <td>0::Male||1::Male</td>
      <td>0::Richard "Richie" Gonzalez||1::Francisco "Pa...</td>
      <td>0::Killed||1::Killed</td>
      <td>0::Victim||1::Victim</td>
      <td>13.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>239661</th>
      <td>1081719</td>
      <td>2018-03-31</td>
      <td>North Carolina</td>
      <td>Kings Mountain</td>
      <td>US 74</td>
      <td>0</td>
      <td>4</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured||Drive-by (car to stree...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239662</th>
      <td>1082388</td>
      <td>2018-03-31</td>
      <td>Minnesota</td>
      <td>Saint Paul</td>
      <td>1000 block of York Ave</td>
      <td>0</td>
      <td>2</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured||Drive-by (car to stree...</td>
      <td>44.9685</td>
      <td>1.0</td>
      <td>0::18||1::22</td>
      <td>0::Male||1::Male</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured</td>
      <td>0::Victim||1::Victim</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239663</th>
      <td>1082197</td>
      <td>2018-03-31</td>
      <td>Oklahoma</td>
      <td>Guthrie</td>
      <td>500 block of Walnut St</td>
      <td>1</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Dead (murder, accidental, suicide)||Off...</td>
      <td>35.8739</td>
      <td>1.0</td>
      <td>0::27</td>
      <td>0::Male</td>
      <td>0::Jason Birt</td>
      <td>0::Killed</td>
      <td>0::Subject-Suspect</td>
      <td>31.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>239664</th>
      <td>1082023</td>
      <td>2018-03-31</td>
      <td>Missouri</td>
      <td>Festus</td>
      <td>4200 block of Hillsboro Hematite Rd</td>
      <td>0</td>
      <td>1</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured</td>
      <td>38.2074</td>
      <td>1.0</td>
      <td>0::63||1::22</td>
      <td>0::Female||1::Male</td>
      <td>1::Garrett Noll</td>
      <td>0::Injured||1::Unharmed, Arrested</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>114.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>239665</th>
      <td>1082226</td>
      <td>2018-03-31</td>
      <td>Missouri</td>
      <td>Saint Clair</td>
      <td>1100 Park Dr</td>
      <td>0</td>
      <td>1</td>
      <td>0::Unknown</td>
      <td>0::Handgun</td>
      <td>Shot - Wounded/Injured||Officer Involved Incid...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0::31||1::56</td>
      <td>0::Male||1::Male</td>
      <td>NaN</td>
      <td>0::Injured||1::Unharmed, Arrested</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239666</th>
      <td>1081894</td>
      <td>2018-03-31</td>
      <td>Missouri</td>
      <td>Saint Louis</td>
      <td>3100 block of California St</td>
      <td>1</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Dead (murder, accidental, suicide)||Acc...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0::7||1::5</td>
      <td>0::Male||1::Male</td>
      <td>0::Jermon Perry</td>
      <td>0::Killed||1::Unharmed</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239667</th>
      <td>1082234</td>
      <td>2018-03-31</td>
      <td>Tennessee</td>
      <td>Memphis</td>
      <td>2900 block of Wingate</td>
      <td>0</td>
      <td>1</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured||Domestic Violence</td>
      <td>35.2045</td>
      <td>1.0</td>
      <td>0::69||1::35</td>
      <td>0::Male||1::Female</td>
      <td>1::Nicole McKinney</td>
      <td>0::Injured||1::Arrested</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>90.0</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>239668</th>
      <td>1081742</td>
      <td>2018-03-31</td>
      <td>Michigan</td>
      <td>Detroit</td>
      <td>I-96</td>
      <td>0</td>
      <td>1</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured||Drive-by (car to stree...</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>0::Injured</td>
      <td>0::Victim</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239669</th>
      <td>1082990</td>
      <td>2018-03-31</td>
      <td>Wisconsin</td>
      <td>Madison</td>
      <td>Hayes Rd</td>
      <td>0</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::45 Auto</td>
      <td>Shots Fired - No Injuries</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239670</th>
      <td>1081752</td>
      <td>2018-03-31</td>
      <td>Illinois</td>
      <td>Chicago</td>
      <td>1 block of N Paulina St</td>
      <td>0</td>
      <td>1</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0::36</td>
      <td>0::Male||1::Male</td>
      <td>NaN</td>
      <td>0::Injured||1::Unharmed</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239671</th>
      <td>1082061</td>
      <td>2018-03-31</td>
      <td>Washington</td>
      <td>Spokane (Spokane Valley)</td>
      <td>12600 block of N Willow Crest Ln</td>
      <td>0</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Non-Shooting Incident||Possession (gun(s) foun...</td>
      <td>47.6638</td>
      <td>1.0</td>
      <td>0::48</td>
      <td>0::Male</td>
      <td>0::Sean M. Gummow</td>
      <td>0::Unharmed, Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>4.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>239672</th>
      <td>1083142</td>
      <td>2018-03-31</td>
      <td>Louisiana</td>
      <td>Rayne</td>
      <td>North Riceland Road and Highway 90</td>
      <td>0</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shots Fired - No Injuries</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0::25</td>
      <td>0::Female</td>
      <td>0::Jhkeya Tezeno</td>
      <td>0::Unharmed, Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239673</th>
      <td>1083139</td>
      <td>2018-03-31</td>
      <td>Louisiana</td>
      <td>Natchitoches</td>
      <td>247 Keyser Ave</td>
      <td>1</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Dead (murder, accidental, suicide)||Ins...</td>
      <td>31.7537</td>
      <td>1.0</td>
      <td>1::21</td>
      <td>0::Male||1::Male</td>
      <td>0::Jamal Haskett||1::Jaquarious Tyjuan Ardison</td>
      <td>0::Killed||1::Unharmed, Arrested</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>23.0</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>239674</th>
      <td>1083151</td>
      <td>2018-03-31</td>
      <td>Louisiana</td>
      <td>Gretna</td>
      <td>1300 block of Cook Street</td>
      <td>0</td>
      <td>1</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Wounded/Injured</td>
      <td>29.9239</td>
      <td>1.0</td>
      <td>0::21</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>0::Injured</td>
      <td>0::Victim</td>
      <td>85.0</td>
      <td>7.0</td>
    </tr>
    <tr>
      <th>239675</th>
      <td>1082514</td>
      <td>2018-03-31</td>
      <td>Texas</td>
      <td>Houston</td>
      <td>12630 Ashford Point Dr</td>
      <td>1</td>
      <td>0</td>
      <td>0::Unknown</td>
      <td>0::Unknown</td>
      <td>Shot - Dead (murder, accidental, suicide)</td>
      <td>29.7201</td>
      <td>1.0</td>
      <td>0::42</td>
      <td>0::Male</td>
      <td>0::Leroy Ellis</td>
      <td>0::Killed</td>
      <td>0::Victim</td>
      <td>149.0</td>
      <td>17.0</td>
    </tr>
    <tr>
      <th>239676</th>
      <td>1081940</td>
      <td>2018-03-31</td>
      <td>Maine</td>
      <td>Norridgewock</td>
      <td>434 Skowhegan Rd</td>
      <td>2</td>
      <td>0</td>
      <td>0::Unknown||1::Unknown</td>
      <td>0::Handgun||1::Shotgun</td>
      <td>Shot - Dead (murder, accidental, suicide)||Sui...</td>
      <td>44.7293</td>
      <td>2.0</td>
      <td>0::58||1::62</td>
      <td>0::Female||1::Male</td>
      <td>0::Marie Lancaster Hale||1::William Hale</td>
      <td>0::Killed||1::Killed</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>111.0</td>
      <td>3.0</td>
    </tr>
  </tbody>
</table>
<p>239677 rows × 19 columns</p>
</div>




```python
df['n_guns_involved'].dropna(inplace=True)
```


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 239677 entries, 0 to 239676
    Data columns (total 29 columns):
    incident_id                    239677 non-null int64
    date                           239677 non-null object
    state                          239677 non-null object
    city_or_county                 239677 non-null object
    address                        223180 non-null object
    n_killed                       239677 non-null int64
    n_injured                      239677 non-null int64
    incident_url                   239677 non-null object
    source_url                     239209 non-null object
    incident_url_fields_missing    239677 non-null bool
    congressional_district         227733 non-null float64
    gun_stolen                     140179 non-null object
    gun_type                       140226 non-null object
    incident_characteristics       239351 non-null object
    latitude                       231754 non-null float64
    location_description           42089 non-null object
    longitude                      231754 non-null float64
    n_guns_involved                140226 non-null float64
    notes                          158660 non-null object
    participant_age                147379 non-null object
    participant_age_group          197558 non-null object
    participant_gender             203315 non-null object
    participant_name               117424 non-null object
    participant_relationship       15774 non-null object
    participant_status             212051 non-null object
    participant_type               214814 non-null object
    sources                        239068 non-null object
    state_house_district           200905 non-null float64
    state_senate_district          207342 non-null float64
    dtypes: bool(1), float64(6), int64(3), object(19)
    memory usage: 50.7+ MB
    


```python
plt.figure(figsize=(20,20))
plt.scatter('n_killed', 'state', data=df)
plt.show()
#This plot tells us that Florida has had the highest number of Deaths related to gun violence in 2018. Let's examine it further.
```


![png](output_12_0.png)



```python
df2 = df[df['state']=='Florida']
```


```python
df2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>incident_id</th>
      <th>date</th>
      <th>state</th>
      <th>city_or_county</th>
      <th>address</th>
      <th>n_killed</th>
      <th>n_injured</th>
      <th>incident_url</th>
      <th>source_url</th>
      <th>incident_url_fields_missing</th>
      <th>...</th>
      <th>participant_age</th>
      <th>participant_age_group</th>
      <th>participant_gender</th>
      <th>participant_name</th>
      <th>participant_relationship</th>
      <th>participant_status</th>
      <th>participant_type</th>
      <th>sources</th>
      <th>state_house_district</th>
      <th>state_senate_district</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>40</th>
      <td>482942</td>
      <td>2013-03-17</td>
      <td>Florida</td>
      <td>Belle Glade</td>
      <td>Northwest 16th Street and Northwest Avenue L</td>
      <td>0</td>
      <td>5</td>
      <td>http://www.gunviolencearchive.org/incident/482942</td>
      <td>http://www.wpbf.com/news/south-florida/palm-be...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.palmbeachpost.com/news/news/crime-l...</td>
      <td>81.0</td>
      <td>25.0</td>
    </tr>
    <tr>
      <th>59</th>
      <td>485821</td>
      <td>2013-04-27</td>
      <td>Florida</td>
      <td>Williston</td>
      <td>County Road 318</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/485821</td>
      <td>https://www.youtube.com/watch?v=AzC_jFR7k6c</td>
      <td>False</td>
      <td>...</td>
      <td>0::36||5::19</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Female||4::Femal...</td>
      <td>0::Barry Barney||1::Kristopher Brumfield||2::N...</td>
      <td>NaN</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.gainesville.com/article/20130428/AR...</td>
      <td>20.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>131</th>
      <td>490793</td>
      <td>2013-07-07</td>
      <td>Florida</td>
      <td>Pompano Beach</td>
      <td>1600 block of Northwest 7th Lane</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/490793</td>
      <td>http://miami.cbslocal.com/2013/07/07/pompano-b...</td>
      <td>False</td>
      <td>...</td>
      <td>0::23||1::54||2::35||3::23</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male||5...</td>
      <td>0::Joshua Childs||1::Alphonso Wright||2::Chris...</td>
      <td>4::Armed Robbery||5::Armed Robbery||6::Armed R...</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured|...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.nbcmiami.com/news/local/1-Dead-3-In...</td>
      <td>92.0</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>151</th>
      <td>491265</td>
      <td>2013-07-26</td>
      <td>Florida</td>
      <td>Hialeah</td>
      <td>1485 W 46th St</td>
      <td>7</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/491265</td>
      <td>https://en.wikipedia.org/wiki/2013_Hialeah_sho...</td>
      <td>False</td>
      <td>...</td>
      <td>0::79||1::69||2::33||3::64||4::51||5::17||6::42</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Female||2::Male||3::Male||4::Femal...</td>
      <td>0::Italo Pisciotti||1::Samira Pisciotti||2::Ca...</td>
      <td>6::Mass shooting - Perp Knows Victims</td>
      <td>0::Killed||1::Killed||2::Killed||3::Killed||4:...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.miamiherald.com/news/special-report...</td>
      <td>110.0</td>
      <td>38.0</td>
    </tr>
    <tr>
      <th>181</th>
      <td>492276</td>
      <td>2013-08-25</td>
      <td>Florida</td>
      <td>Lake Butler</td>
      <td>1050 Southeast 6th Street</td>
      <td>4</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/492276</td>
      <td>http://www.usatoday.com/story/news/nation/2013...</td>
      <td>False</td>
      <td>...</td>
      <td>0::28||1::80||2::66||3::44||4::72</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Rolando Gonzalez-Delgado||1::Marvin Pritche...</td>
      <td>4::Co-worker</td>
      <td>0::Killed||1::Killed||2::Injured||3::Killed||4...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://www.cbsnews.com/news/motive-a-mystery-i...</td>
      <td>19.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>198</th>
      <td>480462</td>
      <td>2013-09-17</td>
      <td>Florida</td>
      <td>Kissimmee</td>
      <td>Flying Fortress Avenue</td>
      <td>0</td>
      <td>5</td>
      <td>http://www.gunviolencearchive.org/incident/480462</td>
      <td>http://articles.orlandosentinel.com/2013-09-19...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://articles.orlandosentinel.com/2013-09-19...</td>
      <td>43.0</td>
      <td>14.0</td>
    </tr>
    <tr>
      <th>203</th>
      <td>480632</td>
      <td>2013-09-21</td>
      <td>Florida</td>
      <td>Palm Beach</td>
      <td>2600 block of Forest Hill Boulevard</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/480632</td>
      <td>http://www.wptv.com/news/region-c-palm-beach-c...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim</td>
      <td>http://www.wptv.com/news/region-c-palm-beach-c...</td>
      <td>87.0</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>222</th>
      <td>481254</td>
      <td>2013-10-20</td>
      <td>Florida</td>
      <td>Margate</td>
      <td>7400 block of Santa Monica Drive</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/481254</td>
      <td>http://www.margatenews.net/3909/123772/a/shoot...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Female</td>
      <td>0::Imron Barett||1::Christopher Currie||2::Ant...</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim</td>
      <td>http://articles.sun-sentinel.com/2013-10-22/ne...</td>
      <td>96.0</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>223</th>
      <td>481263</td>
      <td>2013-10-20</td>
      <td>Florida</td>
      <td>Miami</td>
      <td>19600 block of Southwest 168th Street</td>
      <td>2</td>
      <td>2</td>
      <td>http://www.gunviolencearchive.org/incident/481263</td>
      <td>http://www.local10.com/news/local/2-killed-2-i...</td>
      <td>False</td>
      <td>...</td>
      <td>0::67||2::40||3::49</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>0::Agustin Figueredo||2::Rafael Garcia||3::Ang...</td>
      <td>NaN</td>
      <td>0::Killed||1::Killed||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim</td>
      <td>http://www.miamiherald.com/news/local/communit...</td>
      <td>120.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>226</th>
      <td>481419</td>
      <td>2013-10-26</td>
      <td>Florida</td>
      <td>Miami Gardens</td>
      <td>NW 187 Street and 30 Avenue</td>
      <td>0</td>
      <td>4</td>
      <td>http://www.gunviolencearchive.org/incident/481419</td>
      <td>http://miami.cbslocal.com/2013/10/27/four-inju...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Injured...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim||4:...</td>
      <td>http://miami.cbslocal.com/2013/10/27/four-inju...</td>
      <td>102.0</td>
      <td>36.0</td>
    </tr>
    <tr>
      <th>237</th>
      <td>493109</td>
      <td>2013-11-05</td>
      <td>Florida</td>
      <td>Jacksonville</td>
      <td>1100 block of Randolph</td>
      <td>4</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/493109</td>
      <td>http://jacksonville.com/breaking-news/2013-11-...</td>
      <td>False</td>
      <td>...</td>
      <td>0::25||1::27||2::21||3::22</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Female||3::Female</td>
      <td>0::Derek L. Williams||1::Gontrell M. Hagans||2...</td>
      <td>NaN</td>
      <td>0::Killed||1::Killed||2::Killed||3::Killed</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim</td>
      <td>http://jacksonville.com/breaking-news/2013-11-...</td>
      <td>14.0</td>
      <td>9.0</td>
    </tr>
    <tr>
      <th>256</th>
      <td>495347</td>
      <td>2013-12-01</td>
      <td>Florida</td>
      <td>Miami</td>
      <td>NW 64th Street and 12th Avenue</td>
      <td>2</td>
      <td>2</td>
      <td>http://www.gunviolencearchive.org/incident/495347</td>
      <td>http://www.nbcmiami.com/news/4-Women-Shot-2-De...</td>
      <td>False</td>
      <td>...</td>
      <td>0::18||1::22||2::23</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+</td>
      <td>0::Female||1::Female||2::Female||3::Female</td>
      <td>0::Tiarra Ashonda Grant||1::Shalaunda Williams</td>
      <td>NaN</td>
      <td>0::Killed||1::Killed||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim</td>
      <td>http://miami.cbslocal.com/2013/12/02/liberty-c...</td>
      <td>108.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>263</th>
      <td>495543</td>
      <td>2013-12-15</td>
      <td>Florida</td>
      <td>Homestead (Florida City)</td>
      <td>7th Avenue and 13th Terrace</td>
      <td>1</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/495543</td>
      <td>http://miami.cbslocal.com/2013/12/14/florida-c...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Killed||1::Injured||2::Injured||3::Injured</td>
      <td>0::Victim||1::Victim||2::Victim||3::Victim</td>
      <td>http://www.nbcmiami.com/news/4-Injured-in-Flor...</td>
      <td>120.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>312</th>
      <td>854799</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Milton</td>
      <td>NaN</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/854799</td>
      <td>https://www.atf.gov/news/pr/texas-man-sentence...</td>
      <td>False</td>
      <td>...</td>
      <td>0::31||1::32</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>0::Silvano Zaragoza-Ambriz||1::Kyle James Corbi</td>
      <td>NaN</td>
      <td>0::Unharmed, Arrested||1::Unharmed, Arrested</td>
      <td>0::Subject-Suspect||1::Subject-Suspect</td>
      <td>https://www.atf.gov/news/pr/texas-man-sentence...</td>
      <td>3.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>313</th>
      <td>92497</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Fort Myers</td>
      <td>2600 block of Edison Avenue</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/92497</td>
      <td>http://www.naplesnews.com/news/2014/jan/01/for...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Unharmed||1::Unharmed</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://www.naplesnews.com/news/2014/jan/01/for...</td>
      <td>78.0</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>324</th>
      <td>92479</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Homestead</td>
      <td>13416 Southwest 270th Terrace</td>
      <td>0</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/92479</td>
      <td>http://www.nbcmiami.com/news/3-Shot-During-Rob...</td>
      <td>False</td>
      <td>...</td>
      <td>0::62||1::38||2::37</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+</td>
      <td>0::Female||2::Male||3::Male||4::Male||5::Male</td>
      <td>0::Nereda Morera||1::Jayeski Placencia||2::Ser...</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured||3::Unharme...</td>
      <td>0::Victim||1::Victim||2::Victim||3::Subject-Su...</td>
      <td>http://www.nbcmiami.com/news/3-Shot-During-Rob...</td>
      <td>117.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>325</th>
      <td>92490</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Orlando</td>
      <td>Sun Dew Drive</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/92490</td>
      <td>http://www.orlandosentinel.com/news/local/brea...</td>
      <td>False</td>
      <td>...</td>
      <td>0::34||1::15</td>
      <td>0::Adult 18+||1::Teen 12-17</td>
      <td>0::Male||1::Male</td>
      <td>0::Christopher Albano</td>
      <td>1::Family</td>
      <td>0::Killed||1::Unharmed, Arrested</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://www.orlandosentinel.com/news/local/brea...</td>
      <td>50.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>326</th>
      <td>92501</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Orlando</td>
      <td>5200 block of Via Alizar</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/92501</td>
      <td>http://www.orlandosentinel.com/news/local/brea...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Unharmed||1::Unharmed||2::Unharmed</td>
      <td>0::Victim||1::Subject-Suspect||2::Subject-Suspect</td>
      <td>http://www.orlandosentinel.com/news/local/brea...</td>
      <td>46.0</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>328</th>
      <td>92540</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Orlando</td>
      <td>Sky Lake Circle</td>
      <td>1</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/92540</td>
      <td>http://articles.orlandosentinel.com/2014-05-15...</td>
      <td>False</td>
      <td>...</td>
      <td>0::18||1::20||2::25</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+</td>
      <td>0::Female||1::Male||2::Male</td>
      <td>0::Alliyah Rivera||1::Kristopher Mora||2::Dani...</td>
      <td>NaN</td>
      <td>0::Killed||1::Injured||2::Unharmed, Arrested</td>
      <td>0::Victim||1::Victim||2::Subject-Suspect</td>
      <td>http://www.orlandosentinel.com/news/local/brea...</td>
      <td>48.0</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>341</th>
      <td>92504</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Deltona</td>
      <td>1300 block of W. Hartley Circle</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/92504</td>
      <td>http://www.orlandosentinel.com/news/local/brea...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured||1::Unharmed</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://www.orlandosentinel.com/news/local/brea...</td>
      <td>27.0</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>345</th>
      <td>92487</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Tampa</td>
      <td>2408 W. Kennedy Blvd.</td>
      <td>0</td>
      <td>2</td>
      <td>http://www.gunviolencearchive.org/incident/92487</td>
      <td>http://tbo.com/news/crime/two-men-shot-at-tamp...</td>
      <td>False</td>
      <td>...</td>
      <td>0::27||1::35</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male||2::Male</td>
      <td>0::Calvin Cooper||1::Theodore P. Newman</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Unharmed</td>
      <td>0::Victim||1::Victim||2::Subject-Suspect</td>
      <td>http://tbo.com/news/crime/two-men-shot-at-tamp...</td>
      <td>60.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>420</th>
      <td>92512</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Riviera Beach</td>
      <td>1141 West 31st Street</td>
      <td>1</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/92512</td>
      <td>http://www.wptv.com/dpp/news/region_c_palm_bea...</td>
      <td>False</td>
      <td>...</td>
      <td>0::27||1::29||2::25</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+</td>
      <td>0::Male||1::Female||2::Male</td>
      <td>0::Kelvin Paulk||1::Rackelle Hutchins||2::Jare...</td>
      <td>NaN</td>
      <td>0::Killed||1::Injured||2::Unharmed</td>
      <td>0::Victim||1::Victim||2::Subject-Suspect</td>
      <td>http://www.wptv.com/dpp/news/region_c_palm_bea...</td>
      <td>88.0</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>459</th>
      <td>92560</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Sunrise</td>
      <td>2100 block of 64th Avenue</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/92560</td>
      <td>http://www.sun-sentinel.com/news/local/crime/f...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured||1::Unharmed||2::Unharmed||3::Unhar...</td>
      <td>0::Victim||1::Subject-Suspect||2::Subject-Susp...</td>
      <td>http://www.sun-sentinel.com/news/local/crime/f...</td>
      <td>95.0</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>461</th>
      <td>92522</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Pinellas Park</td>
      <td>NaN</td>
      <td>2</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/92522</td>
      <td>http://www.nbcmiami.com/news/local/Man-Shoots-...</td>
      <td>False</td>
      <td>...</td>
      <td>0::29||1::48</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>0::Anthony McClaney||1::Mitchell Arnold</td>
      <td>NaN</td>
      <td>0::Killed||1::Killed</td>
      <td>0::Victim||1::Victim</td>
      <td>http://www.nbcmiami.com/news/local/Man-Shoots-...</td>
      <td>68.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>489</th>
      <td>100729</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Orlando</td>
      <td>Sun Dew Drive</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/100729</td>
      <td>http://www.myfoxorlando.com/story/24341549/dep...</td>
      <td>False</td>
      <td>...</td>
      <td>0::35||1::15</td>
      <td>0::Adult 18+||1::Teen 12-17</td>
      <td>0::Male||1::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Killed||1::Unharmed</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://www.myfoxorlando.com/story/24341549/dep...</td>
      <td>50.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>491</th>
      <td>92481</td>
      <td>2014-01-01</td>
      <td>Florida</td>
      <td>Jacksonville</td>
      <td>9009 Western Lake Drive</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/92481</td>
      <td>http://jacksonville.com/breaking-news/2014-01-...</td>
      <td>False</td>
      <td>...</td>
      <td>0::46</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Gregory Allen Amole</td>
      <td>NaN</td>
      <td>0::Injured</td>
      <td>0::Victim</td>
      <td>http://jacksonville.com/breaking-news/2014-01-...</td>
      <td>16.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>497</th>
      <td>92524</td>
      <td>2014-01-02</td>
      <td>Florida</td>
      <td>Saint Petersburg</td>
      <td>1833 First Avenue South</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/92524</td>
      <td>http://tbo.com/pinellas-county/man-seriously-i...</td>
      <td>False</td>
      <td>...</td>
      <td>0::27</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Alfred Whitehead</td>
      <td>NaN</td>
      <td>0::Injured</td>
      <td>0::Victim</td>
      <td>http://tbo.com/pinellas-county/man-seriously-i...</td>
      <td>70.0</td>
      <td>19.0</td>
    </tr>
    <tr>
      <th>511</th>
      <td>92530</td>
      <td>2014-01-02</td>
      <td>Florida</td>
      <td>Tampa</td>
      <td>Dale Mabry Highway at Spruce St.</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/92530</td>
      <td>http://www.abcactionnews.com/dpp/news/region_t...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Unharmed</td>
      <td>0::Subject-Suspect</td>
      <td>http://www.abcactionnews.com/dpp/news/region_t...</td>
      <td>62.0</td>
      <td>19.0</td>
    </tr>
    <tr>
      <th>516</th>
      <td>92508</td>
      <td>2014-01-02</td>
      <td>Florida</td>
      <td>Merritt Island</td>
      <td>125 S Banana River Dr</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/92508</td>
      <td>http://www.wesh.com/news/central-florida/breva...</td>
      <td>False</td>
      <td>...</td>
      <td>0::14</td>
      <td>0::Teen 12-17</td>
      <td>0::Female</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured</td>
      <td>0::Victim</td>
      <td>http://www.wesh.com/news/central-florida/breva...</td>
      <td>51.0</td>
      <td>16.0</td>
    </tr>
    <tr>
      <th>517</th>
      <td>92883</td>
      <td>2014-01-02</td>
      <td>Florida</td>
      <td>Crestview</td>
      <td>462 N. Savage Street</td>
      <td>1</td>
      <td>2</td>
      <td>http://www.gunviolencearchive.org/incident/92883</td>
      <td>http://www.nwfdailynews.com/news/20160619/upda...</td>
      <td>False</td>
      <td>...</td>
      <td>2::38||3::33</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>0::Ofc. Beau Baier||1::Ofc. Shane Kriser||2::A...</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Unharmed||3::Killed</td>
      <td>0::Victim||1::Victim||2::Subject-Suspect||3::S...</td>
      <td>http://www.myfoxtampabay.com/story/24358178/su...</td>
      <td>4.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>239175</th>
      <td>1080696</td>
      <td>2018-03-28</td>
      <td>Florida</td>
      <td>Jacksonville</td>
      <td>Norwood Ave and Crestwood St</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.news4jax.com/news/local/jacksonvil...</td>
      <td>False</td>
      <td>...</td>
      <td>0::16||1::19||2::18||3::18</td>
      <td>0::Teen 12-17||1::Adult 18+||2::Adult 18+||3::...</td>
      <td>0::Male||1::Male||2::Male||3::Male</td>
      <td>1::Deon Manick||2::Marquese Holloway||3::Jonat...</td>
      <td>NaN</td>
      <td>0::Unharmed, Arrested||1::Unharmed, Arrested||...</td>
      <td>0::Subject-Suspect||1::Subject-Suspect||2::Sub...</td>
      <td>https://www.news4jax.com/news/local/jacksonvil...</td>
      <td>13.0</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>239181</th>
      <td>1080721</td>
      <td>2018-03-28</td>
      <td>Florida</td>
      <td>Gainesville</td>
      <td>1727 NE 8th Ave</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://mycbs4.com/news/local/bullet-fired-into...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>0::Adult 18+</td>
      <td>0::Female</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured</td>
      <td>0::Victim</td>
      <td>http://mycbs4.com/news/local/bullet-fired-into...</td>
      <td>20.0</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>239182</th>
      <td>1080723</td>
      <td>2018-03-28</td>
      <td>Florida</td>
      <td>Wildwood</td>
      <td>Co Rd 230</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://villages-news.com/village-of-chatham-m...</td>
      <td>False</td>
      <td>...</td>
      <td>0::45</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Jeffrey Joseph Dolence</td>
      <td>NaN</td>
      <td>0::Unharmed, Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>https://villages-news.com/village-of-chatham-m...</td>
      <td>33.0</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>239197</th>
      <td>1079614</td>
      <td>2018-03-28</td>
      <td>Florida</td>
      <td>Tampa</td>
      <td>400 block of W Park Ave</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/107...</td>
      <td>http://www.wtsp.com/article/news/crime/man-dea...</td>
      <td>False</td>
      <td>...</td>
      <td>0::39</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::William F Alexander</td>
      <td>NaN</td>
      <td>0::Killed</td>
      <td>0::Victim</td>
      <td>http://www.wfla.com/news/crime/man-shot-killed...</td>
      <td>61.0</td>
      <td>19.0</td>
    </tr>
    <tr>
      <th>239199</th>
      <td>1079610</td>
      <td>2018-03-28</td>
      <td>Florida</td>
      <td>Riverview</td>
      <td>12524 Burgess Hill Dr</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/107...</td>
      <td>https://www.abcactionnews.com/news/region-hill...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1::Male||2::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Unharmed||1::Unharmed||2::Unharmed</td>
      <td>0::Victim||1::Subject-Suspect||2::Subject-Suspect</td>
      <td>http://www.wfla.com/news/crime/deputies-invest...</td>
      <td>57.0</td>
      <td>19.0</td>
    </tr>
    <tr>
      <th>239236</th>
      <td>1079607</td>
      <td>2018-03-28</td>
      <td>Florida</td>
      <td>Bradenton</td>
      <td>4300 18th St W</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/107...</td>
      <td>http://www.heraldtribune.com/news/20180328/wan...</td>
      <td>False</td>
      <td>...</td>
      <td>0::19</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Rosby Peterson</td>
      <td>NaN</td>
      <td>0::Unharmed, Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>http://www.heraldtribune.com/news/20180328/wan...</td>
      <td>71.0</td>
      <td>21.0</td>
    </tr>
    <tr>
      <th>239243</th>
      <td>1080732</td>
      <td>2018-03-28</td>
      <td>Florida</td>
      <td>Ocala</td>
      <td>2500 block of NE 46th Ave</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.ocala.com/news/20180329/handgun-rep...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>http://www.ocala.com/news/20180329/handgun-rep...</td>
      <td>23.0</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>239316</th>
      <td>1080513</td>
      <td>2018-03-29</td>
      <td>Florida</td>
      <td>Orlando</td>
      <td>2024 W Gore St</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.clickorlando.com/news/man-pistol-w...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Unharmed, Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>https://www.wftv.com/news/local/swat-standoff-...</td>
      <td>46.0</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>239320</th>
      <td>1080671</td>
      <td>2018-03-29</td>
      <td>Florida</td>
      <td>Jacksonville</td>
      <td>N Market St and E 10th St</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.news4jax.com/news/minor-with-rifle...</td>
      <td>False</td>
      <td>...</td>
      <td>0::17</td>
      <td>0::Teen 12-17</td>
      <td>0::Male</td>
      <td>0::Traytavious Martin</td>
      <td>NaN</td>
      <td>0::Unharmed, Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>https://www.news4jax.com/news/minor-with-rifle...</td>
      <td>13.0</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>239396</th>
      <td>1081654</td>
      <td>2018-03-29</td>
      <td>Florida</td>
      <td>Ocala</td>
      <td>3351 S Pine Ave</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.ocala.com/news/20180330/suspicious-...</td>
      <td>False</td>
      <td>...</td>
      <td>0::29</td>
      <td>0::Adult 18+</td>
      <td>0::Female||1::Male</td>
      <td>1::Allfred Spaulding</td>
      <td>NaN</td>
      <td>0::Injured||1::Unharmed, Arrested</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>http://www.ocala.com/news/20180330/suspicious-...</td>
      <td>23.0</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>239403</th>
      <td>1080912</td>
      <td>2018-03-29</td>
      <td>Florida</td>
      <td>Orlando</td>
      <td>NaN</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.orlandosentinel.com/news/breaking-n...</td>
      <td>False</td>
      <td>...</td>
      <td>0::28||1::30||2::31||3::28||4::28</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+||3::A...</td>
      <td>0::Male||1::Male||2::Male||3::Male||4::Male</td>
      <td>0::Kentric Collier||1::Richard Jernigan||2::Ro...</td>
      <td>NaN</td>
      <td>0::Unharmed||1::Unharmed, Arrested||2::Unharme...</td>
      <td>0::Subject-Suspect||1::Subject-Suspect||2::Sub...</td>
      <td>http://www.orlandosentinel.com/news/breaking-n...</td>
      <td>47.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>239410</th>
      <td>1081643</td>
      <td>2018-03-29</td>
      <td>Florida</td>
      <td>Summerfield</td>
      <td>SE 142nd Pl</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://villages-news.com/homeowner-reports-th...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://villages-news.com/homeowner-reports-th...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239411</th>
      <td>1080664</td>
      <td>2018-03-29</td>
      <td>Florida</td>
      <td>Homestead (Florida City)</td>
      <td>US 1</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.local10.com/news/florida/miami-dad...</td>
      <td>False</td>
      <td>...</td>
      <td>0::29</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Jahmal Parker</td>
      <td>NaN</td>
      <td>0::Injured</td>
      <td>0::Subject-Suspect</td>
      <td>https://wsvn.com/news/local/us-1-reopens-in-so...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239412</th>
      <td>1080985</td>
      <td>2018-03-29</td>
      <td>Florida</td>
      <td>Miami</td>
      <td>600 NW 10th St</td>
      <td>1</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://wsvn.com/news/local/1-dead-1-hospitali...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male||1::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Killed||1::Injured</td>
      <td>0::Victim||1::Victim</td>
      <td>https://wsvn.com/news/local/1-dead-1-hospitali...</td>
      <td>109.0</td>
      <td>37.0</td>
    </tr>
    <tr>
      <th>239413</th>
      <td>1081008</td>
      <td>2018-03-29</td>
      <td>Florida</td>
      <td>Miami</td>
      <td>NE Second Ave and NE 58th St</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.local10.com/news/local/miami/polic...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured</td>
      <td>0::Victim</td>
      <td>https://www.local10.com/news/local/miami/polic...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239443</th>
      <td>1081019</td>
      <td>2018-03-30</td>
      <td>Florida</td>
      <td>Key Largo</td>
      <td>Card Sound Rd</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.local10.com/news/florida/monroe-co...</td>
      <td>False</td>
      <td>...</td>
      <td>0::78</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Moises Pedro Arguez</td>
      <td>NaN</td>
      <td>0::Unharmed, Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>https://www.local10.com/news/florida/monroe-co...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239446</th>
      <td>1080989</td>
      <td>2018-03-30</td>
      <td>Florida</td>
      <td>Miami</td>
      <td>2700 SW 33rd Ct</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://wsvn.com/news/local/police-search-for-...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male||1::Male||2::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Unharmed, Arrested||1::Unharmed, Arrested||...</td>
      <td>0::Subject-Suspect||1::Subject-Suspect||2::Sub...</td>
      <td>https://wsvn.com/news/local/police-search-for-...</td>
      <td>112.0</td>
      <td>37.0</td>
    </tr>
    <tr>
      <th>239460</th>
      <td>1080969</td>
      <td>2018-03-30</td>
      <td>Florida</td>
      <td>Eustis</td>
      <td>Glover St and Orange Ave</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.dailycommercial.com/news/20180330/l...</td>
      <td>False</td>
      <td>...</td>
      <td>0::29</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Joshua Brown</td>
      <td>NaN</td>
      <td>0::Killed</td>
      <td>0::Victim</td>
      <td>http://www.dailycommercial.com/news/20180330/m...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239523</th>
      <td>1081026</td>
      <td>2018-03-30</td>
      <td>Florida</td>
      <td>Miami</td>
      <td>8926 NW 22nd Ave</td>
      <td>1</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.local10.com/news/crime/2-shot-at-n...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male||1::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Killed||1::Injured</td>
      <td>0::Victim||1::Victim</td>
      <td>https://www.local10.com/news/crime/2-shot-at-n...</td>
      <td>109.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>239536</th>
      <td>1082498</td>
      <td>2018-03-30</td>
      <td>Florida</td>
      <td>Fort Lauderdale (Lauderhill)</td>
      <td>3100 W Sunrise Blvd</td>
      <td>0</td>
      <td>1</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.nbcmiami.com/news/local/Man-Shot-i...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+</td>
      <td>0::Male||1::Male||2::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured||1::Unharmed||2::Unharmed</td>
      <td>0::Victim||1::Subject-Suspect||2::Subject-Suspect</td>
      <td>https://www.nbcmiami.com/news/local/Man-Shot-i...</td>
      <td>94.0</td>
      <td>33.0</td>
    </tr>
    <tr>
      <th>239602</th>
      <td>1082144</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Miami</td>
      <td>118 NE 2nd St</td>
      <td>0</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://wsvn.com/news/local/man-detained-after...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Unharmed, Arrested</td>
      <td>0::Subject-Suspect</td>
      <td>https://wsvn.com/news/local/man-detained-after...</td>
      <td>113.0</td>
      <td>37.0</td>
    </tr>
    <tr>
      <th>239606</th>
      <td>1082124</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>West Palm Beach</td>
      <td>Webster Ave and Pilgrim Rd</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.wptv.com/news/region-c-palm-beach-...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Killed</td>
      <td>0::Victim</td>
      <td>https://www.wptv.com/news/region-c-palm-beach-...</td>
      <td>87.0</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>239617</th>
      <td>1081647</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Miami</td>
      <td>NW 65th St and NW 13th Ct</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.local10.com/news/local/miami/miami...</td>
      <td>False</td>
      <td>...</td>
      <td>0::4||1::24</td>
      <td>0::Child 0-11||1::Adult 18+</td>
      <td>0::Female||1::Male</td>
      <td>0::Nyla Jones||1::Ronald Jones</td>
      <td>1::Family</td>
      <td>0::Killed||1::Unharmed, Arrested</td>
      <td>0::Victim||1::Subject-Suspect</td>
      <td>https://www.local10.com/news/local/miami/child...</td>
      <td>108.0</td>
      <td>38.0</td>
    </tr>
    <tr>
      <th>239619</th>
      <td>1082157</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Altamonte Springs</td>
      <td>500 block of Georgia Ave</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.clickorlando.com/news/death-invest...</td>
      <td>False</td>
      <td>...</td>
      <td>0::52</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Douglas Adams</td>
      <td>NaN</td>
      <td>0::Killed</td>
      <td>0::Victim</td>
      <td>https://www.clickorlando.com/news/death-invest...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239620</th>
      <td>1082808</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Fort Pierce</td>
      <td>2100 block of Ave N</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.tcpalm.com/story/news/crime/st-luc...</td>
      <td>False</td>
      <td>...</td>
      <td>0::34||1::18||2::17</td>
      <td>0::Adult 18+||1::Adult 18+||2::Teen 12-17</td>
      <td>0::Male||1::Male||2::Female</td>
      <td>0::Tremayne Dellmar||1::Naquion Jones||2::Keit...</td>
      <td>NaN</td>
      <td>0::Killed||1::Unharmed, Arrested||2::Unharmed,...</td>
      <td>0::Victim||1::Subject-Suspect||2::Subject-Suspect</td>
      <td>https://www.tcpalm.com/story/news/crime/st-luc...</td>
      <td>84.0</td>
      <td>25.0</td>
    </tr>
    <tr>
      <th>239622</th>
      <td>1082162</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Bradenton</td>
      <td>3100 block of 15th St E</td>
      <td>0</td>
      <td>2</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.mysuncoast.com/news/investigation-u...</td>
      <td>False</td>
      <td>...</td>
      <td>0::18||1::22</td>
      <td>0::Adult 18+||1::Adult 18+</td>
      <td>0::Male||1::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured</td>
      <td>0::Victim||1::Victim</td>
      <td>http://www.mysuncoast.com/news/investigation-u...</td>
      <td>70.0</td>
      <td>21.0</td>
    </tr>
    <tr>
      <th>239628</th>
      <td>1081639</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Jacksonville</td>
      <td>7900 Block of Lakeland St</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.news4jax.com/news/jacksonville-pol...</td>
      <td>False</td>
      <td>...</td>
      <td>0::31</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Richard Likens</td>
      <td>NaN</td>
      <td>0::Killed</td>
      <td>0::Victim</td>
      <td>https://www.news4jax.com/news/jacksonville-pol...</td>
      <td>15.0</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>239633</th>
      <td>1081645</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Miami</td>
      <td>600 block of NW Second Pl</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>https://www.local10.com/news/local/miami/armed...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Male</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Killed</td>
      <td>0::Subject-Suspect</td>
      <td>https://www.local10.com/news/local/miami/armed...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239635</th>
      <td>1081662</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Tallahassee</td>
      <td>Basin St and W Tennessee St</td>
      <td>1</td>
      <td>0</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.wtxl.com/news/one-killed-in-early-m...</td>
      <td>False</td>
      <td>...</td>
      <td>0::20</td>
      <td>0::Adult 18+</td>
      <td>0::Male</td>
      <td>0::Maurice Brown</td>
      <td>NaN</td>
      <td>0::Killed</td>
      <td>0::Victim</td>
      <td>http://www.wctv.tv/content/news/Early-morning-...</td>
      <td>9.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>239659</th>
      <td>1082057</td>
      <td>2018-03-31</td>
      <td>Florida</td>
      <td>Orlando</td>
      <td>South Kirkman Road and Raleigh Street</td>
      <td>0</td>
      <td>3</td>
      <td>http://www.gunviolencearchive.org/incident/108...</td>
      <td>http://www.orlandosentinel.com/news/breaking-n...</td>
      <td>False</td>
      <td>...</td>
      <td>NaN</td>
      <td>0::Adult 18+||1::Adult 18+||2::Adult 18+</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0::Injured||1::Injured||2::Injured</td>
      <td>0::Victim||1::Victim||2::Victim</td>
      <td>http://www.orlandosentinel.com/news/breaking-n...</td>
      <td>46.0</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
<p>15029 rows × 29 columns</p>
</div>




```python
df2['city_or_county'].values.argmax()
```




    1710




```python

```
